import React from 'react';
import { useParams } from 'react-router-dom';


export function Profile() {
  const { userId } = useParams();

  return (
    <div className="bg-gray-200 p-4">
      <h2 className="text-xl font-bold mb-2">Vehicle/Driver Profile Management</h2>
      <p>User ID: {userId}</p>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Demand Forecasting</h2>
        ...
      </div>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Route Planning and Optimization</h2>
        ...
      </div>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Schedule Generation and Assignment</h2>
        ...
      </div>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Live Vehicle Tracking</h2>
        ...
      </div>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Exception Handling and Auto-Rerouting</h2>
        ...
      </div>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Performance Reporting and Analytics</h2>
        ...
      </div>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Role-Based Access Control</h2>
        ...
      </div>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Responsive Design</h2>
        ...
      </div>
    </div>
  );
}