import React from 'react';
import { useParams } from 'react-router-dom';


export function Route() {
  const { routeId } = useParams();

  return (
    <div className='bg-gray-200 p-4'>
      <h2 className='text-xl font-bold mb-2'>Route {routeId}</h2>

      <div className="bg-gray-200 p-4">
        <h2 className="text-xl font-bold mb-2">Vehicle/Driver Profile Management</h2>
        {/* Your code here */}
      </div>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Demand Forecasting</h2>
        {/* Your code here */}
      </div>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Route Planning and Optimization</h2>
        {/* Your code here */}
      </div>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Schedule Generation and Assignment</h2>
        {/* Your code here */}
      </div>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Live Vehicle Tracking</h2>
        {/* Your code here */}
      </div>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Exception Handling and Auto-Rerouting</h2>
        {/* Your code here */}
      </div>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Performance Reporting and Analytics</h2>
        {/* Your code here */}
      </div>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Role-Based Access Control</h2>
        {/* Your code here */}
      </div>

      <div className="bg-gray-200 p-4 mt-4">
        <h2 className="text-xl font-bold mb-2">Responsive Design</h2>
        {/* Your code here */}
      </div>
    </div>
  );
}