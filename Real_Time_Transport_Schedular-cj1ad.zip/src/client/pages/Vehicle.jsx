import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import getVehicle from '@wasp/queries/getVehicle';

export function Vehicle() {
  const { vehicleId } = useParams();
  const { data: vehicle, isLoading, error } = useQuery(getVehicle, { id: vehicleId });
  const updateVehicleFn = useAction(updateVehicle);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleUpdateVehicle = (updatedVehicle) => {
    updateVehicleFn({ id: vehicleId, ...updatedVehicle });
  };

  return (
    <div className='p-4'>
      <div className='mb-4'>
        <h2 className='text-xl font-bold'>Vehicle Details</h2>
        <p>{vehicle.name}</p>
        <p>{vehicle.model}</p>
        <p>{vehicle.year}</p>
      </div>
      <div>
        <h2 className='text-xl font-bold mb-2'>Edit Vehicle</h2>
        <form onSubmit={handleSubmit(handleUpdateVehicle)}>
          <input
            type='text'
            name='name'
            placeholder='Name'
            defaultValue={vehicle.name}
            ref={register({ required: true })}
            className='px-1 py-2 border rounded text-lg'
          />
          <input
            type='text'
            name='model'
            placeholder='Model'
            defaultValue={vehicle.model}
            ref={register({ required: true })}
            className='px-1 py-2 border rounded text-lg'
          />
          <input
            type='text'
            name='year'
            placeholder='Year'
            defaultValue={vehicle.year}
            ref={register({ required: true })}
            className='px-1 py-2 border rounded text-lg'
          />
          <button
            type='submit'
            className='bg-blue-500 hover:bg-blue-700 px-2 py-2 text-white font-bold rounded'
          >
            Save
          </button>
        </form>
      </div>
    </div>
  );
}